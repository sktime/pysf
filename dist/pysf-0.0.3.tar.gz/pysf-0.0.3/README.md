# pysf
Supervised forecasting of sequential data in Python.
